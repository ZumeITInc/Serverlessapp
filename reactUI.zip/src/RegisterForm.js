import React from 'react';
import './style.css';
import axios from 'axios';
// import bodyParser from 'body-parser';
// import { Link } from 'react-router-dom';





class RegisterForm extends React.Component {
    constructor() {
      super();
      this.state = {
        fields: {},
        errors: {}
      }

      this.handleChange = this.handleChange.bind(this);
      this.submituserRegistrationForm = this.submituserRegistrationForm.bind(this);

    };

    handleChange(e) {
      let fields = this.state.fields;
      fields[e.target.name] = e.target.value;
      this.setState({
        fields
      });

    }

    submituserRegistrationForm(e) {
      e.preventDefault();
      if (this.validateForm()) {
          let fields = {};
          fields["candidatename"]="";
          fields["joblocation"] = "";
          fields["technology"] = "";        
          fields["vendor"] = "";
          fields["client"] = "";
          fields["status"]="";
          fields["rate"]="";
          fields["mobileno"]="";          
          this.setState({fields:fields});
          
         
      }
      var candidatename=this.state.fields.candidatename;
      var joblocation = this.state.fields.joblocation;
      var technology = this.state.fields.technology;
      var vendor =this.state.fields.vendor;
      var client =this.state.fields.client;
      var status =this.state.fields.status;
      var rate=this.state.fields.rate;
      var mobileno=this.state.fields.mobileno;
      var data={
        candidatename:candidatename,
        joblocation:joblocation,
        technology:technology,
        vendor:vendor,
        client:client,
        status:status,
        rate:rate,
        mobileno:mobileno
      }


      axios.post("https://akrs8fw4fh.execute-api.us-east-1.amazonaws.com/list/test", data)
      .then(response=>{
        alert("Submitted")
        console.log(response)
      })
      .catch(error =>{
        console.log(error)
      }
      )
    }

    validateForm() {

      let fields = this.state.fields;
      let errors = {};
      let formIsValid = true;

      if (!fields["candidatename"]) {
        formIsValid = false;
        errors["candidatename"] = "*Fields should not be empty.";
      }

      if (typeof fields["candidatename"] !== "undefined") {
        if (!fields["candidatename"].match("")) {
          formIsValid = false;
          errors["candidatename"] = "*Fields should not be empty.";
        }
      }

      if (!fields["joblocation"]) {
        formIsValid = false;
        errors["joblocation"] = "*Fields should not be empty"      }

      if (typeof fields["joblocation"] !== "undefined") {
        if (!fields["joblocation"].match("")) {
          formIsValid = false;
          errors["joblocation"] = "*Fields should not be empty"        }
      }

      if (!fields["technology"]) {
        formIsValid = false;
        errors["technology"] = "*Fields should not be empty";
      }

      if (typeof fields["technology"] !== "undefined") {
        if (!fields["technology"].match("")) {
          formIsValid = false;
          errors["technology"] = "*Fields should not be empty";
        }
      }
      if (!fields["vendor"]) {
        formIsValid = false;
        errors["vendor"] = "*Fields should not be empty";
      }

      if (typeof fields["technology"] !== "undefined") {
        if (!fields["technology"].match("")) {
          formIsValid = false;
          errors["technology"] = "*Fields should not be empty";
        }
      }

      if (!fields["client"]) {
        formIsValid = false;
        errors["client"] = "*Fields should not be empty"    }

      if (typeof fields["client"] !== "undefined") {
        if (!fields["client"].match("")) {
          formIsValid = false;
          errors["client"] = "*Fields should not be empty"      }
      }

      if (!fields["status"]) {
        formIsValid = false;
        errors["status"] = "*Fields should not be empty"    }

      if (typeof fields["status"] !== "undefined") {
        if (!fields["status"].match("")) {
          formIsValid = false;
          errors["status"] = "*Fields should not be empty"      }
      }
      if (!fields["rate"]) {
        formIsValid = false;
        errors["rate"] = "*Fields should not be empty"  }

      if (typeof fields["rate"] !== "undefined") {
        if (!fields["rate"].match("")) {
          formIsValid = false;
          errors["rate"] = "*Fields should not be empty"    }
      } 

      if (!fields["mobileno"]) {
        formIsValid = false;
        errors["mobileno"] = "Enter Mobile number";
      }

      if (typeof fields["mobileno"] !== "undefined") {
        if (!fields["mobileno"].match("")) {
          formIsValid = false;
          errors["mobileno"] = "*Enter Mobile number.";
        }
      }
      
      


      this.setState({
        errors: errors
      });
      return formIsValid;


    };



  ReactDOM;render(
  ) {
    return (  
      <body>  

         <div class="textbox">
        {/* <h2 class = "heading.a">Submission Form to &nbsp;
         <span class="heading3">Zume</span>
         <span class="heading4">IT</span>
        </h2> */}
       
        <form>
        <div class="column">
        <div class="item">
        <label id='cname'>Candidate Name:</label>
        <input id='cname' type="text" name="candidatename" placeholder="Candidate Name"value={this.state.fields.candidatename} onChange={this.handleChange}  />
        <div className="errorMsg">{this.state.errors.candidatename}</div>
        </div>

        <div class="item">
        <label id='jl'>Job Location</label>
        <input id='jl' type="joblocation" name="joblocation" placeholder= "Job Location"value={this.state.fields.joblocation} onChange={this.handleChange} />
        <div className="errorMsg">{this.state.errors.joblocation}</div>
        </div>

        <div class="item">
        <label id='tch'>Technology:</label>
        <input id='id' type="text" name="technology" placeholder="Technology"value={this.state.fields.technology} onChange={this.handleChange}  />
        <div className="errorMsg">{this.state.errors.technology}</div>
        </div>

        <div class="item">
        <label id='vn'>Vendor:</label>
        <input id='vn' type="text" name="vendor" placeholder="Vendor"value={this.state.fields.vendor} onChange={this.handleChange}  />
        <div className="errorMsg">{this.state.errors.vendor}</div>
        </div>

        <div class="item">
        <label>Client:</label>
        <input type="text" name="client" placeholder="Client"value={this.state.fields.client} onChange={this.handleChange}  />
        <div className="errorMsg">{this.state.errors.client}</div>
        </div>

        <div class="item">
        <label>Status:</label>
        <input type="text" name="status" placeholder="Status"value={this.state.fields.status} onChange={this.handleChange}  />
        <div className="errorMsg">{this.state.errors.status}</div>
        </div>

        <div class="item">
        <label>Rate:</label>
        <input type="text" name="rate" placeholder="Rate"value={this.state.fields.rate} onChange={this.handleChange}  />
        <div className="errorMsg">{this.state.errors.rate}</div>
        </div>

        <div class="item">
        <label id='mblno'>Mobile No:</label>
        <input id='id' type="text" name="mobileno" placeholder="Mobile no"value={this.state.fields.mobileno} onChange={this.handleChange}  />
        <div className="errorMsg">{this.state.errors.mobileno}</div>
        </div>
        
        <div class="btn-block">
          <button type="submit" onClick= {this.submituserRegistrationForm}>Submit</button>
        </div>
        </div>
        </form>
</div>
</body>


      );
  }


}


export default RegisterForm;