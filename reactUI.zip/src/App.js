import React from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import { BrowserRouter as Router, Link, Switch, Route } from "react-router-dom";
import RegisterForm from './RegisterForm';


//import Login from "./login.component";
// import RegisterForm from './RegisterForm';
//import SignUp from "./signup.component";

function App() {
  return (<Router>
    <div className="App">
      <nav className="navbar navbar-expand-lg navbar-light fixed-top">
        <div className="container">
          <Link className="navbar-brand" to={"#"}>
          <div class="heading">
              <center>
               <span class="heading1">Zume</span>
               <span class="heading2">IT</span>
               </center>
               </div>
               
            </Link>
          <div className="collapse navbar-collapse" id="navbarTogglerDemo02">
            <ul className="navbar-nav ml-auto">
              
            <li className="nav-item">
                <Link className="nav-link" to={"/Home"} >Home</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to={"#"}>AboutUs</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to={"#"}>Services</Link>
              </li>
              <li className="nav-item">
                <Link className ="nav-link" to={"/RegisterForm"}>Submission Form</Link>
              </li>
              {/* <li className="nav-item">
                <a className="nav-link" href="https://zumeitinc.auth.us-east-1.amazoncognito.com/signup?client_id=e3nosftr0ik0tel8d0ri58qgj&response_type=code&scope=aws.cognito.signin.user.admin+email+openid+phone+profile&redirect_uri=https://serverlessapp2020.s3.amazonaws.com/index.html">Login</a>
              </li> */}
              
              {/* <li className="nav-item">
                <Link className="nav-link" to={"/sign-up"}>Sign up</Link>
              </li>
               */}
              
            </ul>
          </div>
        </div>
      </nav>
      
      <div className="auth-wrapper">
        <div className="auth-inner">
        
          
          <Switch>
            {/* <Route exact path='/' component={Login} />
            <Route path="#" component={Login} /> */}
            <Route path="/Home" component={App} />
            <Route path= "/RegisterForm" component={RegisterForm} /> 
            {/* <Route path="/sign-up" component={SignUp} /> */}
          </Switch>
          </div>
        </div>
        
      
    </div>
    </Router>
  );
}

export default App;